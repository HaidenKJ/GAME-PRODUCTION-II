using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float walkSpeed = 3f;
    [SerializeField] private float sprintSpeed = 7f;
    [SerializeField] private float crouchSpeed = 1.5f;
    [SerializeField] private float crouchHeight = 1f;
    [SerializeField] private float standHeight = 2f;
    [SerializeField] private float leanAngle = 15f;
    [SerializeField] private float mouseSensitivity = 100f;

    private float xRotation = 0f;
    private bool isCrouching = false;
    private float defaultCameraZRotation = 0f;

    public Transform playerCamera;
    private Rigidbody rb;
    private CapsuleCollider capsuleCollider;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        capsuleCollider = GetComponent<CapsuleCollider>();

        rb.freezeRotation = true;  // Prevents unwanted physics rotation
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        defaultCameraZRotation = playerCamera.localRotation.eulerAngles.z;
    }

    void Update()
    {
        HandleMovement();
        HandleCameraMovement();
        HandleCrouch();
        HandleLeaning();
    }

    void HandleMovement()
    {
        float moveSpeed = walkSpeed;
        if (Input.GetKey(KeyCode.LeftShift)) moveSpeed = sprintSpeed;
        if (isCrouching) moveSpeed = crouchSpeed;

        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 move = transform.right * horizontal + transform.forward * vertical;
        rb.velocity = new Vector3(move.x * moveSpeed, rb.velocity.y, move.z * moveSpeed);
    }

    void HandleCameraMovement()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        playerCamera.localRotation = Quaternion.Euler(xRotation, transform.eulerAngles.y, playerCamera.localRotation.eulerAngles.z);
        transform.Rotate(Vector3.up * mouseX);
    }

    void HandleCrouch()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            isCrouching = !isCrouching;
            capsuleCollider.height = isCrouching ? crouchHeight : standHeight;
            transform.position += Vector3.down * (isCrouching ? 0.5f : -0.5f);
        }
    }

    void HandleLeaning()
    {
        float zRotation = defaultCameraZRotation;

        if (Input.GetKey(KeyCode.Q))
        {
            zRotation = -leanAngle;
        }
        else if (Input.GetKey(KeyCode.E))
        {
            zRotation = leanAngle;
        }

        playerCamera.localRotation = Quaternion.Euler(xRotation, transform.eulerAngles.y, zRotation);
    }
}
