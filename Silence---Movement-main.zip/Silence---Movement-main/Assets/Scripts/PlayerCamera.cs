using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
    [SerializeField] private Transform playerBody;
    [SerializeField] private float mouseSensitivity = 100f;
    [SerializeField] private float leanAngle = 15f;

    private float xRotation = 0f;
    private float defaultCameraZRotation = 0f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked; // Lock cursor for better control
        Cursor.visible = false;
        defaultCameraZRotation = transform.localRotation.eulerAngles.z;
    }

    void Update()
    {
        HandleCameraMovement();
        HandleLeaning();
    }

    void HandleCameraMovement()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        // Vertical rotation (pitch) - only affect the camera
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Prevent flipping

        transform.localRotation = Quaternion.Euler(xRotation, 0f, transform.localRotation.eulerAngles.z);

        // Horizontal rotation (yaw) - rotate the entire player body
        playerBody.Rotate(Vector3.up * mouseX);
    }

    void HandleLeaning()
    {
        float zRotation = defaultCameraZRotation;

        if (Input.GetKey(KeyCode.E))
        {
            zRotation = -leanAngle;
        }
        else if (Input.GetKey(KeyCode.Q))
        {
            zRotation = leanAngle;
        }

        transform.localRotation = Quaternion.Euler(xRotation, 0f, zRotation);
    }
}
